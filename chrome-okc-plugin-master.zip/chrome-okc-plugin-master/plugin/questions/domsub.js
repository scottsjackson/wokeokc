_OKCP.fileQuestions.domsub =
	{
		"dominant": [
			{
				"qid": "95139",
				"text": "Would you enter into a 24/7 TPE Master, slave type relationship in which you would be collared, registered, placed under contract and be ruled 100% by your Master?",
				"answerText": [ "Yes", "No" ],
				"score": [-1, 0],
				"weight": [1, 0]
			},
			{
				"qid": "34665",
				"text": "Who will be responsible for cooking the meals and cleaning the house? Assume you both work.",
				"answerText": [ "I will" , "S/he will" , "We will split or take turns" ],
   			"score": [-1, 1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid": "37748",
				"text": "Even if it isn't your personal style, would you dress accordingly to a partner's wishes, just to make them happy during an outing?",
				"answerText": [ "Yes, without question.", "Yes. within reason.", "No." ],
   			"score": [-1, 0, 1],
				"weight": [1, 1, 1]
			},
			{
				"qid": "38721",
				"text": "Imagine that you and your partner cannot agree on the choice of music. If you were driving and your partner a passenger, how should the music be chosen?",
				"answerText": [ "I would play the music I like." , "I would allow my partner to choose the music." , "We should take turns choosing the music." , "It would be best to keep the stereo off." ],
   			"score": [1, -1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid": "1387",
				"text": "Would you ever engage in a sexual activity you didn't enjoy, just because your partner did?",
				"answerText": [ "Yes" , "No" ],
   			"score": [-1, 1],
				"weight": [1, 1]
			},
			{
				"qid": "86725",
				"text": "If your partner wanted to cut his or her hair way shorter than you like it, what would you do?",
				"answerText": [ "Give them an ultimatum. Keep it long or it's over." , "Argue vehemently to keep it long." , "Express my opinion that it looks better long." , "I'd keep my opinion to myself." ],
				"score": [1, 0, 0, -1],
				"weight": [1, 0, 0, 1]
			},
			{
				"qid": "46632",
				"text": "Do you like the idea of having a partner bathe you?",
				"answerText": [ "Yes.", "No.", "I'm not sure." ],
				"score": [1, 0, 0],
				"weight": [1, 0, 0]
			},
			{
				"qid": "47379",
				"text": "Which would you prefer in terms of distributing decision making power in an 'ideal' relationship?",
				"answerText": [ "I would make most of the decisions." , "My partner would make most of the decisions." , "Decisions made jointly through consensus." , "Distribution based upon traditional gender roles." ],
				"score": [1, -1, 0, 0],
				"weight": [1, 1, 1, 0]
			},
			{
				"qid": "353294",
				"text": "Sexually speaking, how dominant or submissive would you say you are?",
				"answerText": [ "Very Dominant", "Mostly Dominant", "Mostly Submissive", "Very Submissive" ],
				"score": [1, 1, -1, -1],
				"weight": [1, 0.75, 0.75, 1]
			},
			{
				"qid": "353294",
				"text": "Spankings?",
				"answerText": [ "I need them when I'm bad" , "I give them when you're bad" , "I take and receive" , "No thanks" ],
				"score": [-1, 1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "92538",
				"text": "Take this any way you want: Are you a...",
				"answerText": [ "Top" , "Bottom" , "Switch (or \"fluid\")" , "\"Huh?\" (or \"I don't care\")" ],
				"score": [1, -1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "119857",
				"text": "Are you a Submissive/Bottom or Dominant/Top?",
				"answerText": [ "Submissive/Bottom" , "Dominant/Top" , "Switch with a S/B preferance" , "Switch with a D/T preferance" ],
				"score": [-1, 1, -1, 1],
				"weight": [1, 1, 0.5, 0.5]
			},
			{
				"qid": "105755",
				"text": "Would you be willing to be spanked to the point of tears?",
				"answerText": [ "Yes, i've been very naughty" , "No, i'm the one with the paddle!" , "I'm Not Sure" , "Spanking is always wrong" ],
				"score": [-1, 1, -1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "72127",
				"text": "If you found out the person you were dating was into some type of BDSM, how would you react?",
				"answerText": [ "Yes, but I want them to be dominant" , "Yes, but I'd be dominant" , "Not sure, but I'd be willing to try" , "Absolutely not, were finished" ],
				"score": [-1, 1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "97920",
				"text": "When it comes to bdsm...",
				"answerText": ["I'd rather be the dominant person", "I'd rather be the submissive person", "It depends, I can go either way", "I'm not into it / don't know what it is"],
				"score": [1, -1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "151959",
				"text": "I identify as _____ in the bedroom:",
				"answerText": [ "Dominant", "Submissive", "Switch", "Unsure - Not interested in D/S" ],
				"score": [1, -1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid": "143528",
				"text": "If you have a kinky side, do you prefer YOUR PARTNER to be...",
				"answerText": [ "More Dominant" , "More submissive" , "Switch between them" , "I don't have a kinky side" ],
				"score": [-1, 1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid": "145537",
				"text": "Are you into BDSM? are you a dom or sub",
				"answerText": [ "Yes! dom" , "No, its wierd." , "maybe with the right person and comfort level" , "Yes! sub" ],
				"score": [1, 0, 0, -1],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid": "156211",
				"text": "Top or bottom?",
				"answerText": ["Top", "Bottom.", "It depends."],
				"score": [1, -1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid": "80304",
				"text": "What is your BDSM orientation, or are you not kinky?",
				"answerText": ["Prefer to be the Dom or Top", "Prefer to be the sub or bottom", "I really like to switch.", "Not kinky or just too new to know my preference."],
				"score": [1, -1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"85983",
				"text":"Whether or not you have tried it, are you interested in dominating or submitting to your partner in the bedroom?",
				"answerText": [ "Yes, I'm interested in dominating my partner." , "Yes, I'm interested in submitting to my partner." , "Yes, I'm interested in both (switching)." , "No, I am not interested." ],
				"score": [1, -1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"111502",
				"text":"Do you want the people you date to spank you?",
				"answerText": [ "Yes. It’s erotic and really turns me on." , "Yes. I’ve been naughty and need to be punished." , "No, I just spank others." , "No, I'm not into the whole spanking thing at all." ],
				"score": [-1, -1, 1, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"75998",
				"text":"How do you feel about erotic spanking?",
				"answerText": [ "Not for me", "I like to spank", "I like to be spanked", "I like both" ],
				"score": [0, 1, -1, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"97979",
				"text":"When engaging in (consensual) Rough sex with your partner(s)",
				"answerText": [ "I attack them", "They attack me", "We attack each other", "I don't engage in Rough Sex" ],
				"score": [1, -1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"81154",
				"text":"Would you consent to carry a device that tracked your location in real time so that your significant other could locate your position any time they wanted?",
				"answerText": ["Yes.", "No."],
				"score": [-1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"16659",
				"text":"Do you think your partner is with you to serve you with cooking and cleaning up after you?",
				"answerText": ["Yes", "No"],
				"score": [1, 0],
				"weight": [1, 1]
			},
			{
				"qid":"60726",
				"text":"If a trusted partner asked you to submit to them sexually, would you? Assume that this would involve letting them collar you, command you, and have control over you during sex.",
				"answerText": ["Yes.", "No."],
				"score": [-1, 1],
				"weight": [1, 0.2]
			},
			{
				"qid":"93463",
				"text":"Would you ever consent to being a total submissive to another human being?",
				"answerText":["I would wear their collar at all times.","I would be submissive in the bed room.","I am willing to play along, occasionally.","I am a dominant person, and could never submit."],
				"score":[-1,-0.75,-0.5,1],
				"weight":[1,1,1,1]
			},
			{
				"qid":"84005",
				"text":"As an adult, have you ever worn a leash and collar in public?",
				"answerText": ["Yes.", "No."],
				"score": [-1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"48347",
				"text":"Do you think you could ever enjoy being humiliated as part of a sexual experience?",
				"answerText": ["Yes.", "No."],
				"score": [-1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"61733",
				"text":"Would you be pleased if a partner expressed the desire to be sexually humiliated by you?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"62",
				"text":"When in charge of others, how do you tend to be?",
				"answerText": ["Firm and Demanding", "Helpful and Understanding"],
				"score": [1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"76595",
				"text":"When it comes to oral sex which do you prefer?",
				"answerText": ["Give", "Receive", "To both give and get", "Don't like it at all"],
				"score": [-1, 1, 0, 0],
				"weight": [1, 1, 1, 0]
			},
			{
				"qid":"123695",
				"text":"As a kinky submissive what type of role would you prefer?",
				"answerText": ["slave, kajira(-us), toy, etc.", "servant, geisha, maid, secretary, etc.", "pain slut, scene bottom, etc.", "I don't know, am a Dom/me, or am not this kinky"],
				"score": [-1, -1, -1, 1],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"34333",
				"text":"Which do you prefer in a significant other, generally speaking?",
				"answerText": ["Dominance/Aggression", "Submission/Shyness", "A little of both, depending on the situation"],
				"score": [-1, 1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid":"78754",
				"text":"Would you allow your partner to decide what you wear to bed?",
				"answerText": ["Yes, always.", "Yes, sometimes.", "No, never."],
				"score": [-1, 0, 1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"61666",
				"text":"In a relationship, how important is it for you to be in control?",
				"answerText": ["Very important.", "Somewhat important.", "Not at all important."],
				"score": [1, 0, -1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"344180",
				"text":"Preferred position: are you a top or a bottom?",
				"answerText": ["Top", "Bottom", "Versatile"],
				"score": [1, -1, 1],
				"weight": [1, 1, 0.5]
			},
			{
				"qid":"29",
				"text":"Would you rather...",
				"answerText": ["be tied up during sex", "do the tying", "avoid bondage all together"],
				"score": [-1, 1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid":"463",
				"text":"In your ideal sexual encounter, do you take control, or do they?",
				"answerText": ["I take control", "They take control"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"83808",
				"text":"Would you ever consider a relationship where you would take on an exclusive sexual role as master or slave?",
				"answerText": ["Yes, as the master only.", "Yes, as the slave only.", "Yes, as the master or the slave.", "No."],
				"score": [1, -1, 1, -1],
				"weight": [1, 1, 0.7, 1]
			},
			{//Added by RAA
				"qid":"87450",
				"text":"How would you prefer your lover in bed?",
				"answerText": ["Very dominant", "Somewhat dominant", "Neutral or willing to take turns", "Submissive"],
				"score": [-1, -1,0,1],
				"weight": [1, 0.7, 0.7, 1]
			},
			{
				"qid":"9668",
				"text":"Not as in whips and chains, but in general, do you prefer your partner to be...",
				"answerText": ["Dominant", "Submissive", "Balanced"],
				"score": [-1, 1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid": "27177",
				"text": "When planning future activities with your significant other(s), do you generally like to take the lead?",
				"answerText": [ "Yes, most of the time", "Share equally", "No, I'm not a planner. Help!" ],
				"score": [1, 0, 0],
				"weight": [1, 1, 0]
			},
		],


		"submissive": [
			{
				"qid": "95139",
				"text": "Would you enter into a 24/7 TPE Master, slave type relationship in which you would be collared, registered, placed under contract and be ruled 100% by your Master?",
				"answerText": [ "Yes", "No" ],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid": "34665",
				"text": "Who will be responsible for cooking the meals and cleaning the house? Assume you both work.",
				"answerText": [ "I will" , "S/he will" , "We will split or take turns" ],
   			"score": [1, -1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid": "37748",
				"text": "Even if it isn't your personal style, would you dress accordingly to a partner's wishes, just to make them happy during an outing?",
				"answerText": [ "Yes, without question.", "Yes. within reason.", "No." ],
   			"score": [1, 0, -1],
				"weight": [1, 1, 1]
			},
			{
				"qid": "38721",
				"text": "Imagine that you and your partner cannot agree on the choice of music. If you were driving and your partner a passenger, how should the music be chosen?",
				"answerText": [ "I would play the music I like." , "I would allow my partner to choose the music." , "We should take turns choosing the music." , "It would be best to keep the stereo off." ],
   			"score": [-1, 1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid": "1387",
				"text": "Would you ever engage in a sexual activity you didn't enjoy, just because your partner did?",
				"answerText": [ "Yes" , "No" ],
   			"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid": "86725",
				"text": "If your partner wanted to cut his or her hair way shorter than you like it, what would you do?",
				"answerText": [ "Give them an ultimatum. Keep it long or it's over." , "Argue vehemently to keep it long." , "Express my opinion that it looks better long." , "I'd keep my opinion to myself." ],
				"score": [-1, 0, 0, 1],
				"weight": [1, 0, 0, 1]
			},
			{
				"qid": "47379",
				"text": "Which would you prefer in terms of distributing decision making power in an 'ideal' relationship?",
				"answerText": [ "I would make most of the decisions." , "My partner would make most of the decisions." , "Decisions made jointly through consensus." , "Distribution based upon traditional gender roles." ],
				"score": [-1, 1, 0, 0],
				"weight": [1, 1, 1, 0]
			},
			{
				"qid": "353294",
				"text": "Sexually speaking, how dominant or submissive would you say you are?",
				"answerText": [ "Very Dominant", "Mostly Dominant", "Mostly Submissive", "Very Submissive" ],
				"score": [-1, -1, 1, 1],
				"weight": [1, 0.75, 0.75, 1]
			},
			{
				"qid": "353294",
				"text": "Spankings?",
				"answerText": [ "I need them when I'm bad" , "I give them when you're bad" , "I take and receive" , "No thanks" ],
				"score": [1, -1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "92342",
				"text": "Take this any way you want: Are you a...",
				"answerText": [ "SLAVE", "MASTER", "NEITHER" ],
				"score": [1, -1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid": "92538",
				"text": "Take this any way you want: Are you a...",
				"answerText": [ "Top" , "Bottom" , "Switch (or \"fluid\")" , "\"Huh?\" (or \"I don't care\")" ],
				"score": [-1, 1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "119857",
				"text": "Are you a Submissive/Bottom or Dominant/Top?",
				"answerText": [ "Submissive/Bottom" , "Dominant/Top" , "Switch with a S/B preferance" , "Switch with a D/T preferance" ],
				"score": [1, -1, 1, -1],
				"weight": [1, 1, 0.5, 0.5]
			},
			{
				"qid": "105755",
				"text": "Would you be willing to be spanked to the point of tears?",
				"answerText": [ "Yes, i've been very naughty" , "No, i'm the one with the paddle!" , "I'm Not Sure" , "Spanking is always wrong" ],
				"score": [1, -1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "72127",
				"text": "If you found out the person you were dating was into some type of BDSM, how would you react?",
				"answerText": [ "Yes, but I want them to be dominant" , "Yes, but I'd be dominant" , "Not sure, but I'd be willing to try" , "Absolutely not, were finished" ],
				"score": [1, -1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "97920",
				"text": "When it comes to bdsm...",
				"answerText": ["I'd rather be the dominant person", "I'd rather be the submissive person", "It depends, I can go either way", "I'm not into it / don't know what it is"],
				"score": [-1, 1, 1, 0],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid": "151959",
				"text": "I identify as _____ in the bedroom:",
				"answerText": [ "Dominant", "Submissive", "Switch", "Unsure - Not interested in D/S" ],
				"score": [-1, 1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid": "143528",
				"text": "If you have a kinky side, do you prefer YOUR PARTNER to be...",
				"answerText": [ "More Dominant" , "More submissive" , "Switch between them" , "I don't have a kinky side" ],
				"score": [1, -1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid": "145537",
				"text": "Are you into BDSM? are you a dom or sub",
				"answerText": [ "Yes! dom" , "No, its wierd." , "maybe with the right person and comfort level" , "Yes! sub" ],
				"score": [-1, 0, 0, 1],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid": "156211",
				"text": "Top or bottom?",
				"answerText": ["Top", "Bottom.", "It depends."],
				"score": [-1, 1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid":"85983",
				"text":"Whether or not you have tried it, are you interested in dominating or submitting to your partner in the bedroom?",
				"answerText": [ "Yes, I'm interested in dominating my partner." , "Yes, I'm interested in submitting to my partner." , "Yes, I'm interested in both (switching)." , "No, I am not interested." ],
				"score": [-1, 1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"111502",
				"text":"Do you want the people you date to spank you?",
				"answerText": [ "Yes. It’s erotic and really turns me on." , "Yes. I’ve been naughty and need to be punished." , "No, I just spank others." , "No, I'm not into the whole spanking thing at all." ],
				"score": [1, 1, -1, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"75998",
				"text":"How do you feel about erotic spanking?",
				"answerText": [ "Not for me", "I like to spank", "I like to be spanked", "I like both" ],
				"score": [0, -1, 1, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"97979",
				"text":"When engaging in (consensual) Rough sex with your partner(s)",
				"answerText": [ "I attack them", "They attack me", "We attack each other", "I don't engage in Rough Sex" ],
				"score": [-1, 1, 0, 0],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"81154",
				"text":"Would you consent to carry a device that tracked your location in real time so that your significant other could locate your position any time they wanted?",
				"answerText": ["Yes.", "No."],
				"score": [1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"60726",
				"text":"If a trusted partner asked you to submit to them sexually, would you? Assume that this would involve letting them collar you, command you, and have control over you during sex.",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 0.2]
			},
			{
				"qid":"93463",
				"text":"Would you ever consent to being a total submissive to another human being?",
				"answerText":["I would wear their collar at all times.","I would be submissive in the bed room.","I am willing to play along, occasionally.","I am a dominant person, and could never submit."],
				"score":[1,0.75,0.5,-1],
				"weight":[1,1,1,1]
			},
			{
				"qid":"84005",
				"text":"As an adult, have you ever worn a leash and collar in public?",
				"answerText": ["Yes.", "No."],
				"score": [1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"48347",
				"text":"Do you think you could ever enjoy being humiliated as part of a sexual experience?",
				"answerText": ["Yes.", "No."],
				"score": [1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"61733",
				"text":"Would you be pleased if a partner expressed the desire to be sexually humiliated by you?",
				"answerText": ["Yes.", "No."],
				"score": [1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"62",
				"text":"When in charge of others, how do you tend to be?",
				"answerText": ["Firm and Demanding", "Helpful and Understanding"],
				"score": [-1, 0],
				"weight": [1, 0]
			},
			{
				"qid":"76595",
				"text":"When it comes to oral sex which do you prefer?",
				"answerText": ["Give", "Receive", "To both give and get", "Don't like it at all"],
				"score": [1, -1, 0, 0],
				"weight": [1, 1, 1, 0]
			},
			{
				"qid":"123695",
				"text":"As a kinky submissive what type of role would you prefer?",
				"answerText": ["slave, kajira(-us), toy, etc.", "servant, geisha, maid, secretary, etc.", "pain slut, scene bottom, etc.", "I don't know, am a Dom/me, or am not this kinky"],
				"score": [1, 1, 1, -1],
				"weight": [1, 1, 1, 1]
			},
			{
				"qid":"34333",
				"text":"Which do you prefer in a significant other, generally speaking?",
				"answerText": ["Dominance/Aggression", "Submission/Shyness", "A little of both, depending on the situation"],
				"score": [1, -1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid":"78754",
				"text":"Would you allow your partner to decide what you wear to bed?",
				"answerText": ["Yes, always.", "Yes, sometimes.", "No, never."],
				"score": [1, 0, -1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"1488",
				"text":"Would you wear your partner's underclothing if they wanted you to?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"54433",
				"text":"Would you ever consider being with someone who demands complete control over everything you wear?",
				"answerText": ["Yes.", "No."],
				"score": [1, 0],
				"weight": [1, 1]
			},
			{
				"qid":"61666",
				"text":"In a relationship, how important is it for you to be in control?",
				"answerText": ["Very important.", "Somewhat important.", "Not at all important."],
				"score": [-1, 0, 1],
				"weight": [1, 1, 1]
			},
			{
				"qid":"344180",
				"text":"Preferred position: are you a top or a bottom?",
				"answerText": ["Top", "Bottom", "Versatile"],
				"score": [-1, 1, 1],
				"weight": [1, 1, 0.5]
			},
			{
				"qid":"29",
				"text":"Would you rather...",
				"answerText": ["be tied up during sex", "do the tying", "avoid bondage all together"],
				"score": [1, -1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid": "60756",
				"text": "If your partner wanted you to say a specific phrase during sex, would you?",
				"answerText": ["Yes, I'd say anything they want me to.", "No, I wouldn't.", "Maybe, it would depend upon the phrase."],
				"score": [1, -1, -1],
				"weight": [1, 1, 0.5]
			},
			{
				"qid": "150317",
				"text": "Have you ever become sexually aroused as a result of being spanked?\n",
				"answerText": ["Yes", "No"],
				"score": [1, 0],
				"weight": [1, 0.5]
			},
			{
				"qid":"463",
				"text":"In your ideal sexual encounter, do you take control, or do they?",
				"answerText": ["I take control", "They take control"],
				"score": [-1, 1],
				"weight": [1, 1]
			},
			{
				"qid":"38320",
				"text":"Is it generally acceptable to you for a sex partner to initiate foreplay while you are sleeping?",
				"answerText": ["Yes.", "No."],
				"score": [1, -1],
				"weight": [1, 1]
			},
			{
				"qid":"83808",
				"text":"Would you ever consider a relationship where you would take on an exclusive sexual role as master or slave?",
				"answerText": ["Yes, as the master only.", "Yes, as the slave only.", "Yes, as the master or the slave.", "No."],
				"score": [-1, 1, 1, -1],
				"weight": [1, 1, 0.7, 1]
			},
			{
				"qid":"79635",
				"text":"How would you feel if someone called you \"good girl\" or \"good boy\" during sex?",
				"answerText": ["Positive.", "Negative.", "Indifferent.", "It would depend on which of the two I was called."],
				"score": [1, -1, 0, 1],
				"weight": [1, 1, 0.5, 1]
			},
			{
				"qid":"11",
				"text":"How does the idea of being slapped hard in the face during sex make you feel?",
				"answerText": ["Horrified", "Aroused", "Nostalgic", "Indifferent"],
				"score": [-1, 1, 1, 0],
				"weight": [1, 1, 0.7, 0.6]
			},
			{
				"qid":"1011",
				"text":"Do you know what a 'safeword' is, in a sexual context?",
				"answerText": ["Yes", "No"],
				"score": [1, -1],
				"weight": [0.1, 1]
			},
			{//Added by RAA
				"qid":"87450",
				"text":"How would you prefer your lover in bed?",
				"answerText": ["Very dominant", "Somewhat dominant", "Neutral or willing to take turns", "Submissive"],
				"score": [1, 1,0,-1],
				"weight": [1, 0.7, 0.7, 1]
			},
			{
				"qid":"9668",
				"text":"Not as in whips and chains, but in general, do you prefer your partner to be...",
				"answerText": ["Dominant", "Submissive", "Balanced"],
				"score": [1, -1, 0],
				"weight": [1, 1, 1]
			},
			{
				"qid":"38646",
				"text":"If a significant other requested that you stop wearing antiperspirant or deodorant, is this something you would seriously consider?",
				"answerText": [ "Yes." , "No." , "I am already totally 'natural' in this way." ],
   			"score": [1, 0, 0],
				"weight": [1, 0, 0]
			},
			{
				"qid": "801",
				"text": "Are you willing to sit with your mate and watch their favorite TV show with them, even if it's one that you can't stand?",
				"answerText": [ "Yes", "No", "ONLY if they're willing to do the same for me" ],
   			"score": [1, 0, 0],
				"weight": [1, 0, 0]
			},
			{
				"qid": "22206",
				"text": "Would you radically alter your appearance (hair, clothes, body modifications) for your significant other?",
				"answerText": [ "Yes" , "No way!" , "I'm not sure, it depends..." ],
   			"score": [1, 0, 0],
				"weight": [1, 0, 0]
			},
			{
				"qid":"30",
				"text":"Would you like to receive pain during sex?",
				"answerText": ["Yes, lots and lots", "Yes, some", "No"],
				"score": [1, 0.3, 0],
				"weight": [1, 1, 0]
			},
			{
				"qid":"28545",
				"text":"When having sex, do you like to have your hair pulled?",
				"answerText": ["Yes, and hard!", "Yes, but gently.", "No way.", "Don't know / Not sure."],
				"score": [1, 0.3, 0, 0],
				"weight": [1, 1, 0, 0]
			},
		]
	};

